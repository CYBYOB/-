<?php
    define('host', '118.24.107.196');
    define('user', 'cyb');
    define('password', 'cyb123456');
    define('database', 'tongyou');
?>