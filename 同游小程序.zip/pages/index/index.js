//index.js
//获取应用实例
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 轮播图的列表
    carousel_list: [
      { id: '1', src: '/images/test/1.png' },
      { id: '2', src: '/images/test/1.png' },
      { id: '3', src: '/images/test/1.png' },
    ],

    // 大区列表，默认选中中国
    big_area_list: ['中国', '亚洲', '欧洲', '北美洲', '大洋洲', '其他'],
    // 小区列表
    mini_area_list: ['全部','北京','上海','成都','三亚','广州','重庆','深圳','西安','其他'],
    // 筛选结果列表
    result_list: [
      { id: '0', src:'/images/test/1.png', name: '大阪', rate: '85.00', visit_time: '3' },
      { id: '1', src:'/images/test/1.png', name: '大阪', rate: '82.40', visit_time: '3' },
      { id: '2', src:'/images/test/1.png', name: '大阪', rate: '85.33', visit_time: '3' },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})