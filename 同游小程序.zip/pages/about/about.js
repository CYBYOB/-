// pages/about/abouts.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    func_list: [
      { src: '/images/about/about_0.png', text: '灵活随机旅程' },
      { src: '/images/about/about_1.png', text: '为家人制造惊喜' },
      { src: '/images/about/about_0.png', text: '共同规划旅程' },
      { src: '/images/about/about_0.png', text: '系统个性化推荐' },
    ],

    // 成员信息
    team_list: [
      { name: '杜诗琪', school: '四川美术学院' },
      { name: '陈元宝', school: '西安电子科技大学' },
      { name: '朱家豪', school: '四川美术学院' },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})